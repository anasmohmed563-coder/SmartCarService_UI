package services;

import database.DatabaseConnection;
import models.Customer;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {

    // Replacement for the old static map - now strictly using SQL
    public static void addCustomer(Customer customer) {
        String sql = "INSERT INTO customers (customer_id, first_name, last_name, email, phone_number, address, registration_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, customer.getCustomerId());
            stmt.setString(2, customer.getFirstName());
            stmt.setString(3, customer.getLastName());
            stmt.setString(4, customer.getEmail());
            stmt.setString(5, customer.getPhoneNumber());
            stmt.setString(6, customer.getAddress());
            stmt.setString(7, customer.getRegistrationDate());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Same name, same return type (Map) for UI compatibility
    public static Map<String, Customer> getAllCustomers() {
        Map<String, Customer> customers = new HashMap<>();
        String sql = "SELECT * FROM customers WHERE is_active = 1";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Customer c = new Customer(
                        rs.getString("customer_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("phone_number"),
                        rs.getString("address")
                );
                customers.put(c.getCustomerId(), c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }

    // Same name, implementing Soft Delete (isActive = 0)
    public static boolean deleteCustomer(String customerId) {
        String sql = "UPDATE customers SET is_active = 0 WHERE customer_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, customerId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}