package services;

import database.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
    private static final int MAX_APPOINTMENTS_PER_SERVICE = 5;

    // 1. CREATE: Add appointment with capacity check
    public static void addAppointment(Object[] appointment) {
        String date = (String) appointment[9];
        String serviceType = (String) appointment[10];

        // SQL Capacity Check (Replaces Map logic)
        int currentCount = getAppointmentCount(date, serviceType);

        if (currentCount >= MAX_APPOINTMENTS_PER_SERVICE) {
            throw new IllegalArgumentException("Seçtiğiniz tarihte '" + serviceType + "' atölyemiz tam kapasiteye (5/5) ulaşmıştır.");
        }

        String sql = "INSERT INTO services (service_id, vehicle_id, customer_id, service_type, start_date, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, (String) appointment[0]); // serviceId
            stmt.setString(2, (String) appointment[1]); // vehicleId
            stmt.setString(3, (String) appointment[2]); // customerId
            stmt.setString(4, serviceType);
            stmt.setString(5, date);
            stmt.setString(6, "PENDING"); // Initial status

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 2. READ: Get count for specific date and service (Real-time SQL)
    public static int getAppointmentCount(String date, String serviceType) {
        if (serviceType == null || serviceType.startsWith("--")) return 0;

        String sql = "SELECT COUNT(*) FROM services WHERE start_date = ? AND service_type = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, date);
            stmt.setString(2, serviceType);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    // 3. READ: Get all appointments for UI
    public static List<Object[]> getAllAppointments() {
        List<Object[]> appointments = new ArrayList<>();
        String sql = "SELECT * FROM services";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Object[] app = new Object[11];
                app[0] = rs.getString("service_id");
                app[1] = rs.getString("vehicle_id");
                app[2] = rs.getString("customer_id");
                // Fill placeholders to match UI array structure if needed
                app[9] = rs.getString("start_date");
                app[10] = rs.getString("service_type");
                appointments.add(app);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return appointments;
    }

    // 4. DELETE: Hard Delete to free up capacity
    public static boolean deleteAppointment(String appointmentId) {
        String sql = "DELETE FROM services WHERE service_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, appointmentId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}