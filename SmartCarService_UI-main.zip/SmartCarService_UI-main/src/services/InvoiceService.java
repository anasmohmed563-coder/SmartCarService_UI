package services;

import database.DatabaseConnection;
import models.Invoice;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InvoiceService {

    // 1. CREATE: Add new invoice to Database
    public static void addInvoice(Invoice invoice) {
        if (invoice == null) return;

        String sql = "INSERT INTO invoices (invoice_id, customer_id, vehicle_id, subtotal, tax_amount, total_amount, payment_status, invoice_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, invoice.getInvoiceId());
            stmt.setString(2, invoice.getCustomerId());
            stmt.setString(3, invoice.getVehicleId());
            stmt.setDouble(4, invoice.getSubtotal());
            stmt.setDouble(5, invoice.getTaxAmount());
            stmt.setDouble(6, invoice.getTotalAmount());
            stmt.setString(7, invoice.getPaymentStatus().toString());
            stmt.setString(8, invoice.getInvoiceDate());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 2. READ: Get all active invoices for Admin Panel
    public static List<Invoice> getAllInvoices() {
        List<Invoice> invoices = new ArrayList<>();
        String sql = "SELECT * FROM invoices WHERE is_active = 1";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // Mapping SQL to Invoice Object
                Invoice inv = new Invoice(
                        rs.getString("invoice_id"),
                        rs.getString("customer_id"),
                        rs.getString("vehicle_id"),
                        "SERVICE-000", // Placeholder service ID as per Model
                        0 // Due days placeholder
                );
                inv.setPaymentStatus(Invoice.PaymentStatus.valueOf(rs.getString("payment_status")));
                invoices.add(inv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return invoices;
    }

    // 3. READ: Find specific invoice by ID
    public static Invoice getInvoiceById(String invoiceId) {
        String sql = "SELECT * FROM invoices WHERE invoice_id = ? AND is_active = 1";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, invoiceId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Invoice inv = new Invoice(
                        rs.getString("invoice_id"),
                        rs.getString("customer_id"),
                        rs.getString("vehicle_id"),
                        "SERVICE-000",
                        0
                );
                inv.setPaymentStatus(Invoice.PaymentStatus.valueOf(rs.getString("payment_status")));
                return inv;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 4. READ: Get invoices by Customer ID
    public static List<Invoice> getInvoicesByCustomerId(String customerId) {
        List<Invoice> customerInvoices = new ArrayList<>();
        String sql = "SELECT * FROM invoices WHERE customer_id = ? AND is_active = 1";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, customerId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Invoice inv = new Invoice(
                        rs.getString("invoice_id"),
                        rs.getString("customer_id"),
                        rs.getString("vehicle_id"),
                        "SERVICE-000",
                        0
                );
                inv.setPaymentStatus(Invoice.PaymentStatus.valueOf(rs.getString("payment_status")));
                customerInvoices.add(inv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customerInvoices;
    }

    // 5. UPDATE: Mark as Paid
    public static boolean markAsPaid(String invoiceId) {
        String sql = "UPDATE invoices SET payment_status = 'PAID' WHERE invoice_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, invoiceId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}