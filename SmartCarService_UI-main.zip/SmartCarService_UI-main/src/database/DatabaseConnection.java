package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static Connection connection = null;
    private static final String URL = "jdbc:sqlite:smart_car.db";

    // Private constructor for Singleton pattern
    private DatabaseConnection() {}

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection(URL);
                initializeDatabase();
            } catch (ClassNotFoundException e) {
                System.err.println("SQLite Driver not found!");
                e.printStackTrace();
            }
        }
        return connection;
    }

    private static void initializeDatabase() {
        // Updated to include all tables matching your Models
        String customersTable = "CREATE TABLE IF NOT EXISTS customers (" +
                "customer_id TEXT PRIMARY KEY, first_name TEXT, last_name TEXT, " +
                "email TEXT, phone_number TEXT, address TEXT, " +
                "registration_date TEXT, is_active INTEGER DEFAULT 1)";

        String invoicesTable = "CREATE TABLE IF NOT EXISTS invoices (" +
                "invoice_id TEXT PRIMARY KEY, customer_id TEXT, vehicle_id TEXT, " +
                "subtotal REAL, tax_amount REAL, total_amount REAL, " +
                "payment_status TEXT, invoice_date TEXT, is_active INTEGER DEFAULT 1)";

        String vehiclesTable = "CREATE TABLE IF NOT EXISTS vehicles (" +
                "vehicle_id TEXT PRIMARY KEY, customer_id TEXT, make TEXT, " +
                "model TEXT, year TEXT, license_plate TEXT, vin_number TEXT, mileage INTEGER)";

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(customersTable);
            stmt.execute(invoicesTable);
            stmt.execute(vehiclesTable);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}