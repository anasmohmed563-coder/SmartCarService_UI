package services;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import models.Customer;
import database.DatabaseConnection;

public class CustomerService {

    // Save to SQLite
    public static void addCustomer(Customer customer) {
        String sql = "INSERT INTO customers(name, email, phone) VALUES(?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getEmail());
            pstmt.setString(3, customer.getPhoneNumber());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("DB Insert Error: " + e.getMessage());
        }
    }

    // Fetch from Database
    public static Map<String, Customer> getAllCustomers() {
        Map<String, Customer> customers = new HashMap<>();
        String sql = "SELECT * FROM customers WHERE isActive = 1";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Customer c = new Customer(
                        String.valueOf(rs.getInt("id")),
                        rs.getString("name"),
                        "",
                        rs.getString("email"),
                        rs.getString("phone"),
                        ""
                );
                customers.put(c.getCustomerId(), c);
            }
        } catch (SQLException e) {
            System.out.println("DB Fetch Error: " + e.getMessage());
        }
        return customers;
    }

    // Soft Delete
    public static void deleteCustomer(String customerId) {
        String sql = "UPDATE customers SET isActive = 0 WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, Integer.parseInt(customerId));
            int rows = pstmt.executeUpdate();

        } catch (SQLException | NumberFormatException e) {
            System.out.println("DB Delete Error: " + e.getMessage());
        }
    }
}