package services;

import database.DatabaseConnection;
import models.Invoice;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InvoiceService {

    // Keep list for UI syncing
    private static List<Invoice> allInvoices = new ArrayList<>();

    // 1. CREATE: Save to DB instead of just RAM
    public static void addInvoice(Invoice invoice) {
        if (invoice == null) {
            throw new IllegalArgumentException("Boş fatura sisteme eklenemez!");
        }

        String sql = "INSERT INTO invoices(customerName, subtotal, taxAmount, totalAmount, isActive) VALUES(?,?,?,?,1)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, invoice.getCustomerId());
            pstmt.setDouble(2, invoice.getSubtotal());
            pstmt.setDouble(3, invoice.getTaxAmount());
            pstmt.setDouble(4, invoice.getTotalAmount());
            pstmt.executeUpdate();

            // Still sync with local list for the Admin Panel
            allInvoices.add(invoice);
            System.out.println("Sisteme yeni fatura eklendi: " + invoice.getInvoiceId());

        } catch (SQLException e) {
            System.out.println("DB Error (Add Invoice): " + e.getMessage());
        }
    }

    // 2. READ: Returns current list (Synced with DB)
    public static List<Invoice> getAllInvoices() {
        return allInvoices;
    }

    // 3. READ: Find by ID (From local list to keep it fast)
    public static Invoice getInvoiceById(String invoiceId) {
        for (Invoice inv : allInvoices) {
            if (inv.getInvoiceId().equals(invoiceId)) {
                return inv;
            }
        }
        return null;
    }

    // 4. READ: Filter by Customer ID
    public static List<Invoice> getInvoicesByCustomerId(String customerId) {
        List<Invoice> customerInvoices = new ArrayList<>();
        for (Invoice inv : allInvoices) {
            if (inv.getCustomerId().equals(customerId)) {
                customerInvoices.add(inv);
            }
        }
        return customerInvoices;
    }

    // 5. UPDATE: Mark as Paid in DB
    public static boolean markAsPaid(String invoiceId) {
        String sql = "UPDATE invoices SET status = 'PAID' WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, Integer.parseInt(invoiceId));
            int rows = pstmt.executeUpdate();

            if (rows > 0) {
                // Update local object status too
                Invoice invoice = getInvoiceById(invoiceId);
                if (invoice != null) {
                    invoice.setPaymentStatus(Invoice.PaymentStatus.PAID);
                }
                return true;
            }
        } catch (SQLException | NumberFormatException e) {
            System.out.println("DB Error (Mark Paid): " + e.getMessage());
        }
        return false;
    }
}