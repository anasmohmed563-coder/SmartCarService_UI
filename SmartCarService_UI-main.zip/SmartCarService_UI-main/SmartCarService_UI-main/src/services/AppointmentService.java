package services;

import database.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppointmentService {
    // Exact same variables as your Raw Code
    private static List<Object[]> allAppointments = new ArrayList<>();
    private static Map<String, Integer> serviceCapacityCounts = new HashMap<>();
    private static final int MAX_APPOINTMENTS_PER_SERVICE = 5;

    public static void addAppointment(Object[] appointment) {
        String date = (String) appointment[9];
        String serviceType = (String) appointment[10];
        String capacityKey = date + "_" + serviceType;

        int currentCount = serviceCapacityCounts.getOrDefault(capacityKey, 0);

        // Capacity check logic - exactly as you wrote it
        if (currentCount >= MAX_APPOINTMENTS_PER_SERVICE) {
            throw new IllegalArgumentException("Seçtiğiniz tarihte '" + serviceType + "' atölyemiz tam kapasiteye (5/5) ulaşmıştır.");
        }

        // SQL Integration
        String sql = "INSERT INTO appointments(customerName, vehicleModel, status, date) VALUES(?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, (String) appointment[1]); // customerName
            pstmt.setString(2, (String) appointment[4]); // vehicleModel
            pstmt.setString(3, (String) appointment[11]); // status
            pstmt.setString(4, date);
            pstmt.executeUpdate();

            // Sync RAM for the UI components
            serviceCapacityCounts.put(capacityKey, currentCount + 1);
            allAppointments.add(appointment);

        } catch (SQLException e) {
            System.out.println("DB Error: " + e.getMessage());
        }
    }

    public static List<Object[]> getAllAppointments() {
        return allAppointments;
    }

    public static int getAppointmentCount(String date, String serviceType) {
        if(serviceType == null || serviceType.startsWith("--")) return 0;
        return serviceCapacityCounts.getOrDefault(date + "_" + serviceType, 0);
    }

    public static boolean deleteAppointment(String appointmentId) {
        String sql = "DELETE FROM appointments WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, Integer.parseInt(appointmentId));
            int rows = pstmt.executeUpdate();

            if (rows > 0) {
                // Sync RAM list and capacity after successful deletion
                for (int i = 0; i < allAppointments.size(); i++) {
                    if (allAppointments.get(i)[0].equals(appointmentId)) {
                        String date = (String) allAppointments.get(i)[9];
                        String serviceType = (String) allAppointments.get(i)[10];
                        serviceCapacityCounts.put(date + "_" + serviceType,
                                serviceCapacityCounts.get(date + "_" + serviceType) - 1);
                        allAppointments.remove(i);
                        break;
                    }
                }
                return true;
            }
        } catch (SQLException | NumberFormatException e) {
            System.out.println("Delete Error: " + e.getMessage());
        }
        return false;
    }
}