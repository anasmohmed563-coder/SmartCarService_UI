package database;

import java.sql.*;

public class DatabaseConnection {
    private static Connection conn = null;
    private static final String URL = "jdbc:sqlite:smart_car.db";

    // Singleton connection access
    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            try {
                Class.forName("org.sqlite.JDBC");
                conn = DriverManager.getConnection(URL);
                createSchema();
            } catch (ClassNotFoundException e) {
                System.err.println("JDBC Driver not found");
            }
        }
        return conn;
    }

    // Initialize tables to match your existing models
    private static void createSchema() {
        try (Statement stmt = conn.createStatement()) {
            // Customer table + isActive for soft delete
            stmt.execute("CREATE TABLE IF NOT EXISTS customers (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT, email TEXT, phone TEXT, isActive INTEGER DEFAULT 1)");

            // Appointment table
            stmt.execute("CREATE TABLE IF NOT EXISTS appointments (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "customerName TEXT, vehicleModel TEXT, status TEXT, date TEXT)");

            // Invoices table - stores your final calculated values (NVP results)
            stmt.execute("CREATE TABLE IF NOT EXISTS invoices (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "customerName TEXT, subtotal DOUBLE, taxAmount DOUBLE, totalAmount DOUBLE, isActive INTEGER DEFAULT 1)");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}